package demo_jdbc;

import java.util.List;
import java.util.stream.Collectors;

import demo_jdbc.models.Constructors;
import demo_jdbc.respositories.ConstructorsRepository;
import demo_jdbc.models.Season;
import demo_jdbc.respositories.SeasonRepository;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Crear pantalla de menú principal
        VBox mainMenu = new VBox(20);
        mainMenu.setStyle("-fx-padding: 20; -fx-alignment: center; -fx-background-color: #f0f0f0;");
        
        Label titleLabel = new Label("Constructor Results");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        
        Button tableMenuButton = new Button("IR TABLEVIEW DRIVERS");
        Button barChartMenuButton = new Button("IR GRAFICO DE BARRAS DE DRIVERS POINTS");

        tableMenuButton.setStyle("-fx-font-size: 14px; -fx-padding: 10px;");
        barChartMenuButton.setStyle("-fx-font-size: 14px; -fx-padding: 10px;");
        
        mainMenu.getChildren().addAll(titleLabel, tableMenuButton, barChartMenuButton);

        Scene mainMenuScene = new Scene(mainMenu, 800, 600);
        
        // Crear comboBox para seleccionar el año
        ComboBox<String> yearComboBox = createComboBox();

        // Crear la tabla y el diagrama de barras
        TableView<Constructors> tableView = createTableView();
        BarChart<String, Number> barChart = createBarChart();

        // Crear botones para el menú de tablas y diagramas
        Button showTableButton = new Button("TABLEVIEW DRIVERS");
        Button showBarChartButton = new Button("GRAFICO DE BARRAS DE DRIVERS POINTS");

        showTableButton.setStyle("-fx-font-size: 14px; -fx-padding: 10px;");
        showBarChartButton.setStyle("-fx-font-size: 14px; -fx-padding: 10px;");
        
        // Crear contenedores para la tabla y el diagrama de barras
        StackPane tablePane = new StackPane(tableView);
        StackPane chartPane = new StackPane(barChart);

        // Ocultar la tabla y el diagrama de barras al inicio
        tablePane.setVisible(false);
        chartPane.setVisible(false);

        // Agregar acción a los botones del menú
        showTableButton.setOnAction(e -> {
            tablePane.setVisible(true);
            chartPane.setVisible(false);
        });

        showBarChartButton.setOnAction(e -> {
            tablePane.setVisible(false);
            chartPane.setVisible(true);
        });

        // Configurar el comboBox para actualizar la tabla y el diagrama de barras
        yearComboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                try {
                    int selectedYear = Integer.parseInt(newValue);
                    ConstructorsRepository constructorsRepository = new ConstructorsRepository();
                    List<Constructors> results = constructorsRepository.getResultByYear(selectedYear);
                    if (results != null) {
                        tableView.setItems(FXCollections.observableArrayList(results));
                        updateBarChart(barChart, results);
                    } else {
                        System.out.println("No se encontraron resultados para el año " + selectedYear);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        // Crear contenedor principal para la vista de tablas y diagramas
        HBox menuBox = new HBox(20, showTableButton, showBarChartButton);
        menuBox.setStyle("-fx-padding: 10px; -fx-alignment: center;");

        VBox mainBox = new VBox(20, menuBox, yearComboBox, tablePane, chartPane);
        mainBox.setStyle("-fx-padding: 20px;");
        Scene mainScene = new Scene(mainBox, 800, 600);

        // Acciones de los botones del menú principal
        tableMenuButton.setOnAction(e -> primaryStage.setScene(mainScene));
        barChartMenuButton.setOnAction(e -> {
            tablePane.setVisible(false);
            chartPane.setVisible(true);
            primaryStage.setScene(mainScene);
        });

        // Mostrar el menú principal al inicio
        primaryStage.setScene(mainMenuScene);
        primaryStage.setTitle("Constructor Results");
        primaryStage.show();
    }

    public ComboBox<String> createComboBox() {
        ComboBox<String> comboBox = new ComboBox<>();
        comboBox.setPrefSize(150, 30);
        comboBox.setStyle("-fx-font-size: 14px;");

        SeasonRepository seasonRepository = new SeasonRepository();
        List<Season> years = seasonRepository.getSeasons().stream()
                .sorted((s1, s2) -> Integer.compare(s1.getYear(), s2.getYear()))
                .collect(Collectors.toList());

        for (Season season : years) {
            comboBox.getItems().add(String.valueOf(season.getYear()));
        }

        comboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            System.out.println("Ha seleccionado el año: " + newValue);
        });

        return comboBox;
    }

    public TableView<Constructors> createTableView() {
        TableView<Constructors> tableView = new TableView<>();

        TableColumn<Constructors, String> nameColumn = new TableColumn<>("Constructor Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Constructors, Integer> winsColumn = new TableColumn<>("Wins");
        winsColumn.setCellValueFactory(new PropertyValueFactory<>("wins"));

        TableColumn<Constructors, Integer> totalPointsColumn = new TableColumn<>("Total Points");
        totalPointsColumn.setCellValueFactory(new PropertyValueFactory<>("totalPoints"));

        TableColumn<Constructors, Integer> rankColumn = new TableColumn<>("Rank");
        rankColumn.setCellValueFactory(new PropertyValueFactory<>("seasonRank"));

        tableView.getColumns().add(nameColumn);
        tableView.getColumns().add(winsColumn);
        tableView.getColumns().add(totalPointsColumn);
        tableView.getColumns().add(rankColumn);

        return tableView;
    }

    public BarChart<String, Number> createBarChart() {
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Constructor");

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Total Points");

        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Total Points by Constructor");

        return barChart;
    }

    public void updateBarChart(BarChart<String, Number> barChart, List<Constructors> results) {
        barChart.getData().clear();

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Total Points");

        for (Constructors constructor : results) {
            series.getData().add(new XYChart.Data<>(constructor.getName(), constructor.getTotalPoints()));
        }

        barChart.getData().add(series);
    }

    public static void main(String[] args) {
        launch(args);
    }
}

