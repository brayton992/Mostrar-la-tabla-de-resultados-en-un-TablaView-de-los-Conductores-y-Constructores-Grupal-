package demo_jdbc.respositories;

public class RaceRepository {

}
